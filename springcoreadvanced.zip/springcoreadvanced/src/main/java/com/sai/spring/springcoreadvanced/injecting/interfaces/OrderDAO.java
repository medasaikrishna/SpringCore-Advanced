package com.sai.spring.springcoreadvanced.injecting.interfaces;

public interface OrderDAO {

	void createOrder();
}
