package com.sai.spring.springcoreadvanced.stereotype.annotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"com/sai/spring/springcoreadvanced/stereotype/annotations/config.xml");
		Instructor e = (Instructor) ctx.getBean("instructor");
		//Instructor e1 = (Instructor) ctx.getBean("instructor");
		System.out.println(e);

	}

}
