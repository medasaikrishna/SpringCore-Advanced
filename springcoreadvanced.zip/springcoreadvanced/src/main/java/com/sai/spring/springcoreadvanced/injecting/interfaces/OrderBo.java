package com.sai.spring.springcoreadvanced.injecting.interfaces;

public interface OrderBo {
	void placeOrder();

}
