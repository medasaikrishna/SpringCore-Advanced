package com.sai.spring.springcoreadvanced.standalonecollections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"com/sai/spring/springcoreadvanced/standalonecollections/config.xml");
		ProductsList e = (ProductsList) ctx.getBean("productslist");

		System.out.println(e);

	}

}
