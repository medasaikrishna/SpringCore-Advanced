package com.sai.spring.springcoreadvanced.injecting.interfaces;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext c=new ClassPathXmlApplicationContext("com/sai/spring/springcoreadvanced/injecting/interfaces/config.xml");
		OrderBo ab=(OrderBo) c.getBean("bo");
		ab.placeOrder();
	}

}
